import { useState } from 'react';
import { Search, Check, ArrowLeft, MapPin, Building2, X } from 'lucide-react';
import { countriesData, University } from '../utils/countryData';

type UniversityBrowserProps = {
  selectedCountries: string[];
  selectedUniversities: string[];
  onComplete: (universities: string[]) => void;
  onBack: () => void;
};

export function UniversityBrowser({ 
  selectedCountries, 
  selectedUniversities: initialSelected,
  onComplete, 
  onBack 
}: UniversityBrowserProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUniversities, setSelectedUniversities] = useState<string[]>(initialSelected);
  const [activeCountry, setActiveCountry] = useState<string | null>(
    selectedCountries.length > 0 ? selectedCountries[0] : null
  );

  // Filter countries based on selected countries
  const availableCountries = selectedCountries.length > 0
    ? countriesData.filter(c => selectedCountries.includes(c.name))
    : countriesData;

  // Get universities for active country
  const activeCountryData = availableCountries.find(c => c.name === activeCountry);
  const universities = activeCountryData?.universities || [];

  // Filter universities based on search
  const filteredUniversities = universities.filter(uni =>
    uni.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    uni.city.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleUniversity = (universityName: string) => {
    setSelectedUniversities(prev =>
      prev.includes(universityName)
        ? prev.filter(u => u !== universityName)
        : [...prev, universityName]
    );
  };

  const handleComplete = () => {
    onComplete(selectedUniversities);
  };

  const removeUniversity = (universityName: string) => {
    setSelectedUniversities(prev => prev.filter(u => u !== universityName));
  };

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-gray-900 mb-2">Biblioteca de Universidades</h1>
            <p className="text-gray-600">
              Navegue e selecione as universidades de interesse
            </p>
          </div>
          <button
            onClick={onBack}
            className="px-4 py-2 text-gray-700 hover:bg-white rounded-lg transition-colors inline-flex items-center gap-2"
          >
            <ArrowLeft className="w-5 h-5" />
            Voltar
          </button>
        </div>

        {/* Selected Universities Bar */}
        {selectedUniversities.length > 0 && (
          <div className="bg-white rounded-xl p-4 mb-6 shadow-lg sticky top-6 z-10">
            <div className="flex items-center justify-between mb-3">
              <p className="text-gray-900">
                {selectedUniversities.length} universidade(s) selecionada(s)
              </p>
              <button
                onClick={handleComplete}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors inline-flex items-center gap-2"
              >
                <Check className="w-5 h-5" />
                Confirmar Seleção
              </button>
            </div>
            <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
              {selectedUniversities.map(uni => (
                <div
                  key={uni}
                  className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-900 rounded-lg border border-indigo-200"
                >
                  <span className="text-sm">{uni}</span>
                  <button
                    onClick={() => removeUniversity(uni)}
                    className="text-indigo-400 hover:text-red-500"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Countries Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg p-4 sticky top-28">
              <h3 className="text-gray-900 mb-4">Países</h3>
              <div className="space-y-2">
                {availableCountries.map(country => (
                  <button
                    key={country.name}
                    onClick={() => setActiveCountry(country.name)}
                    className={`w-full p-3 rounded-lg text-left transition-all ${
                      activeCountry === country.name
                        ? 'bg-indigo-600 text-white'
                        : 'bg-gray-50 text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{country.flag}</span>
                      <div className="flex-1 min-w-0">
                        <p className="truncate">{country.name}</p>
                        <p className={`${
                          activeCountry === country.name ? 'text-indigo-200' : 'text-gray-500'
                        }`}>
                          {country.universities.length} universidades
                        </p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Universities List */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-xl shadow-lg p-6">
              {/* Search */}
              <div className="mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscar universidades..."
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              {/* Country Header */}
              {activeCountryData && (
                <div className="mb-6 p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <span className="text-4xl">{activeCountryData.flag}</span>
                    <div>
                      <h2 className="text-gray-900">{activeCountryData.name}</h2>
                      <p className="text-gray-600">
                        {filteredUniversities.length} de {universities.length} universidades
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Universities Grid */}
              {filteredUniversities.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredUniversities.map((university) => {
                    const isSelected = selectedUniversities.includes(university.name);
                    return (
                      <button
                        key={university.name}
                        onClick={() => toggleUniversity(university.name)}
                        className={`p-4 border-2 rounded-lg text-left transition-all ${
                          isSelected
                            ? 'border-indigo-600 bg-indigo-50'
                            : 'border-gray-200 hover:border-indigo-300 hover:bg-gray-50'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start gap-2 mb-2">
                              <Building2 className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                                isSelected ? 'text-indigo-600' : 'text-gray-400'
                              }`} />
                              <div className="flex-1 min-w-0">
                                <p className={`font-medium mb-1 ${
                                  isSelected ? 'text-indigo-900' : 'text-gray-900'
                                }`}>
                                  {university.name}
                                </p>
                                <div className="flex items-center gap-1 text-gray-600">
                                  <MapPin className="w-3 h-3" />
                                  <span className="text-sm">{university.city}</span>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 mt-2">
                              {university.ranking && (
                                <span className="px-2 py-1 bg-amber-100 text-amber-700 rounded text-xs">
                                  #{university.ranking} Nacional
                                </span>
                              )}
                              <span className={`px-2 py-1 rounded text-xs ${
                                university.type === 'Pública' 
                                  ? 'bg-green-100 text-green-700'
                                  : 'bg-blue-100 text-blue-700'
                              }`}>
                                {university.type}
                              </span>
                            </div>
                          </div>
                          {isSelected && (
                            <div className="flex-shrink-0">
                              <div className="w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center">
                                <Check className="w-4 h-4 text-white" />
                              </div>
                            </div>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-500">
                    {searchQuery 
                      ? 'Nenhuma universidade encontrada com esse termo'
                      : 'Selecione um país para ver as universidades'}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
