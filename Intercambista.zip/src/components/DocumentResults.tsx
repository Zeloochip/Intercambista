import { UserProfile } from '../App';
import { FileText, AlertCircle, CheckCircle2, Download, Printer, ArrowLeft, Calendar, Globe, BookOpen, Building2, ChevronDown, ChevronUp } from 'lucide-react';
import { countriesData } from '../utils/countryData';
import { useState } from 'react';

type DocumentResultsProps = {
  profile: UserProfile;
  onBack: () => void;
};

type Document = {
  id: string;
  name: string;
  description: string;
  required: boolean;
  category: string;
  processingTime?: string;
  notes?: string;
};

type UniversityDocuments = {
  universityName: string;
  country: string;
  documents: Document[];
  specificNotes?: string[];
};

// Generate documents specific to a university
function generateDocumentsForUniversity(
  universityName: string, 
  profile: UserProfile
): Document[] {
  const universityData = countriesData
    .flatMap(c => c.universities.map(u => ({ ...u, country: c.name })))
    .find(u => u.name === universityName);

  const isInternational = universityData?.country !== profile.country;
  const isPGProgram = ['Mestrado', 'Doutorado', 'Pós-Graduação', 'MBA'].includes(profile.programType);

  const baseDocuments: Document[] = [
    {
      id: 'doc1',
      name: 'Formulário de Inscrição',
      description: `Formulário oficial de candidatura da ${universityName}`,
      required: true,
      category: 'Administrativo',
      processingTime: '1 dia',
      notes: 'Disponível no portal da universidade'
    },
    {
      id: 'doc2',
      name: 'Documento de Identidade',
      description: 'Cópia autenticada do RG ou CNH',
      required: true,
      category: 'Identificação',
      processingTime: '1 semana'
    },
  ];

  // Add CPF for Brazilian universities or if student is Brazilian
  if (universityData?.country === 'Brasil' || profile.country === 'Brasil') {
    baseDocuments.push({
      id: 'doc3',
      name: 'CPF',
      description: 'Cópia do Cadastro de Pessoa Física',
      required: true,
      category: 'Identificação'
    });
  }

  baseDocuments.push(
    {
      id: 'doc4',
      name: 'Histórico Escolar',
      description: 'Histórico escolar completo com todas as notas',
      required: true,
      category: 'Acadêmico',
      processingTime: '2-3 semanas',
      notes: isInternational ? 'Deve estar traduzido e apostilado' : undefined
    },
    {
      id: 'doc5',
      name: 'Diploma ou Certificado',
      description: 'Diploma do último nível educacional concluído',
      required: true,
      category: 'Acadêmico',
      processingTime: '2-4 semanas',
      notes: isInternational ? 'Deve estar traduzido e apostilado' : undefined
    }
  );

  // International requirements
  if (isInternational) {
    baseDocuments.push(
      {
        id: 'doc6',
        name: 'Passaporte',
        description: 'Passaporte válido por pelo menos 6 meses após a data de entrada',
        required: true,
        category: 'Viagem',
        processingTime: '4-6 semanas',
        notes: 'Certifique-se de que tenha páginas em branco suficientes'
      },
      {
        id: 'doc7',
        name: 'Visto de Estudante',
        description: `Visto de estudante para ${universityData?.country}`,
        required: true,
        category: 'Viagem',
        processingTime: '2-3 meses',
        notes: 'Agende a entrevista no consulado com antecedência'
      }
    );

    // Language proficiency based on country
    if (universityData?.country === 'Estados Unidos' || 
        universityData?.country === 'Reino Unido' || 
        universityData?.country === 'Austrália' || 
        universityData?.country === 'Canadá') {
      baseDocuments.push({
        id: 'doc8',
        name: 'TOEFL ou IELTS',
        description: `Certificado de proficiência em inglês exigido pela ${universityName}`,
        required: true,
        category: 'Idioma',
        processingTime: 'Resultados em 2 semanas',
        notes: 'Verifique a pontuação mínima específica desta universidade'
      });
    } else if (universityData?.country === 'França') {
      baseDocuments.push({
        id: 'doc8',
        name: 'DELF/DALF ou TCF',
        description: 'Certificado de proficiência em francês',
        required: true,
        category: 'Idioma',
        processingTime: 'Resultados em 2-3 semanas',
        notes: 'Nível B2 ou superior geralmente exigido'
      });
    } else if (universityData?.country === 'Alemanha') {
      baseDocuments.push({
        id: 'doc8',
        name: 'TestDaF ou DSH',
        description: 'Certificado de proficiência em alemão',
        required: true,
        category: 'Idioma',
        processingTime: 'Resultados em 4-6 semanas',
        notes: 'Nível B2/C1 geralmente exigido, alguns programas em inglês disponíveis'
      });
    } else if (universityData?.country === 'Espanha' || universityData?.country === 'Portugal') {
      baseDocuments.push({
        id: 'doc8',
        name: 'DELE/SIELE ou CELPE-Bras',
        description: 'Certificado de proficiência em espanhol ou português',
        required: false,
        category: 'Idioma',
        processingTime: 'Resultados em 2-3 semanas',
        notes: 'Pode ser dispensado para falantes nativos'
      });
    } else {
      baseDocuments.push({
        id: 'doc8',
        name: 'Certificado de Proficiência em Idioma',
        description: 'Certificado de proficiência no idioma local',
        required: true,
        category: 'Idioma',
        processingTime: 'Varia',
        notes: 'Consulte a universidade sobre requisitos específicos'
      });
    }

    baseDocuments.push({
      id: 'doc10',
      name: 'Comprovante Financeiro',
      description: 'Extratos bancários comprovando capacidade financeira',
      required: true,
      category: 'Financeiro',
      notes: 'Geralmente requer demonstração de fundos para pelo menos 1 ano acadêmico'
    });
  }

  // Postgraduate requirements
  if (isPGProgram) {
    baseDocuments.push(
      {
        id: 'doc11',
        name: 'Cartas de Recomendação',
        description: `2-3 cartas exigidas pela ${universityName}`,
        required: true,
        category: 'Acadêmico',
        processingTime: '2-3 semanas',
        notes: 'Solicite com antecedência aos seus recomendadores'
      },
      {
        id: 'doc12',
        name: 'Carta de Motivação',
        description: 'Ensaio explicando objetivos e motivações',
        required: true,
        category: 'Acadêmico',
        notes: 'Siga as diretrizes específicas da universidade (geralmente 500-1000 palavras)'
      },
      {
        id: 'doc13',
        name: 'Currículo Acadêmico / CV',
        description: 'Currículo detalhado com experiências',
        required: true,
        category: 'Profissional'
      }
    );

    // Research programs
    if (profile.programType === 'Mestrado' || profile.programType === 'Doutorado') {
      baseDocuments.push({
        id: 'doc14',
        name: 'Proposta de Pesquisa',
        description: 'Proposta detalhada do projeto de pesquisa',
        required: profile.programType === 'Doutorado',
        category: 'Acadêmico',
        notes: 'Essencial para programas de pesquisa'
      });
    }

    // MBA specific
    if (profile.programType === 'MBA') {
      baseDocuments.push({
        id: 'doc15',
        name: 'GMAT ou GRE',
        description: 'Pontuação nos testes padronizados',
        required: false,
        category: 'Testes',
        processingTime: 'Resultados imediatos',
        notes: `${universityName} pode dispensar para candidatos com experiência significativa`
      });

      baseDocuments.push({
        id: 'doc16',
        name: 'Comprovante de Experiência Profissional',
        description: 'Cartas de empregadores ou contratos de trabalho',
        required: true,
        category: 'Profissional',
        notes: 'Mínimo de 2-5 anos geralmente exigido'
      });
    }
  }

  // Photos
  baseDocuments.push({
    id: 'doc17',
    name: 'Fotografias',
    description: 'Fotos recentes no formato exigido',
    required: true,
    category: 'Identificação',
    notes: 'Formato pode variar - consulte requisitos da universidade'
  });

  // Country-specific documents
  if (universityData?.country === 'Estados Unidos') {
    baseDocuments.push({
      id: 'doc18',
      name: 'Form I-20',
      description: 'Formulário I-20 emitido pela universidade',
      required: true,
      category: 'Viagem',
      notes: 'Você receberá após ser aceito e confirmar matrícula'
    });

    baseDocuments.push({
      id: 'doc19',
      name: 'Taxa SEVIS',
      description: 'Comprovante de pagamento da taxa SEVIS I-901',
      required: true,
      category: 'Administrativo',
      notes: 'Deve ser pago antes da entrevista do visto'
    });
  }

  if (universityData?.country === 'Alemanha') {
    baseDocuments.push({
      id: 'doc20',
      name: 'Conta Bloqueada (Sperrkonto)',
      description: 'Conta bloqueada com valor mínimo exigido',
      required: true,
      category: 'Financeiro',
      notes: 'Aproximadamente €11,904 para 2025'
    });

    baseDocuments.push({
      id: 'doc21',
      name: 'APS Certificate',
      description: 'Certificado de avaliação acadêmica',
      required: profile.country === 'China' || profile.country === 'Vietnã',
      category: 'Acadêmico',
      notes: 'Obrigatório para estudantes de certos países'
    });
  }

  if (universityData?.country === 'Reino Unido') {
    baseDocuments.push({
      id: 'doc22',
      name: 'CAS (Confirmation of Acceptance)',
      description: 'Confirmação de aceitação para estudos',
      required: true,
      category: 'Administrativo',
      notes: 'Emitido pela universidade após aceitação'
    });

    baseDocuments.push({
      id: 'doc23',
      name: 'Teste de Tuberculose',
      description: 'Certificado médico de teste de TB',
      required: true,
      category: 'Médico',
      notes: 'Obrigatório para vistos de mais de 6 meses'
    });
  }

  if (universityData?.country === 'Canadá') {
    baseDocuments.push({
      id: 'doc24',
      name: 'Letter of Acceptance',
      description: 'Carta de aceitação oficial da universidade',
      required: true,
      category: 'Administrativo',
      notes: 'Necessária para solicitar o study permit'
    });
  }

  if (universityData?.country === 'França') {
    baseDocuments.push({
      id: 'doc25',
      name: 'Processo Campus France',
      description: 'Registro e entrevista no Campus France',
      required: true,
      category: 'Administrativo',
      notes: 'Obrigatório para estudantes brasileiros'
    });
  }

  // University-specific requirements based on university name
  if (universityName.includes('Oxford') || universityName.includes('Cambridge')) {
    baseDocuments.push({
      id: 'doc26',
      name: 'Admission Test',
      description: 'Teste de admissão específico do curso',
      required: true,
      category: 'Testes',
      notes: 'Ex: TSA, BMAT, LNAT - varia por curso'
    });
  }

  if (universityName.includes('Harvard') || universityName.includes('MIT') || 
      universityName.includes('Stanford')) {
    baseDocuments.push({
      id: 'doc27',
      name: 'SAT ou ACT',
      description: 'Pontuações de testes padronizados',
      required: profile.programType === 'Graduação',
      category: 'Testes',
      notes: 'Algumas universidades adotaram políticas test-optional'
    });
  }

  return baseDocuments;
}

// Generate all university documents
function generateAllDocuments(profile: UserProfile): UniversityDocuments[] {
  return profile.targetUniversities.map(uniName => {
    const university = countriesData
      .flatMap(c => c.universities.map(u => ({ ...u, country: c.name })))
      .find(u => u.name === uniName);

    const documents = generateDocumentsForUniversity(uniName, profile);
    
    const specificNotes: string[] = [];
    
    if (university) {
      specificNotes.push(`📍 Localização: ${university.city}, ${university.country}`);
      
      if (university.type === 'Privada') {
        specificNotes.push('💰 Universidade privada - verifique valores de matrícula e mensalidades');
      }
      
      if (university.ranking) {
        specificNotes.push(`🏆 Ranking #${university.ranking} nacional - processo seletivo altamente competitivo`);
      }
    }

    return {
      universityName: uniName,
      country: university?.country || '',
      documents,
      specificNotes
    };
  });
}

export function DocumentResults({ profile, onBack }: DocumentResultsProps) {
  const [expandedUniversity, setExpandedUniversity] = useState<string | null>(
    profile.targetUniversities[0] || null
  );

  const allUniversityDocs = generateAllDocuments(profile);
  const totalDocuments = allUniversityDocs.reduce((sum, ud) => sum + ud.documents.length, 0);

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    alert('Função de download será implementada com backend real');
  };

  const toggleUniversity = (uniName: string) => {
    setExpandedUniversity(expandedUniversity === uniName ? null : uniName);
  };

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <button
          onClick={onBack}
          className="mb-6 px-4 py-2 text-gray-700 hover:bg-white rounded-lg transition-colors inline-flex items-center gap-2"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar ao Dashboard
        </button>

        {/* Results Header */}
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-6">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h1 className="text-gray-900 mb-2">Documentos por Universidade</h1>
              <p className="text-gray-600">
                Requisitos específicos para cada uma das {profile.targetUniversities.length} universidades selecionadas
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handlePrint}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors inline-flex items-center gap-2"
              >
                <Printer className="w-5 h-5" />
                Imprimir
              </button>
              <button
                onClick={handleDownload}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors inline-flex items-center gap-2"
              >
                <Download className="w-5 h-5" />
                Baixar PDF
              </button>
            </div>
          </div>

          {/* Profile Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-indigo-50 rounded-xl">
            <div>
              <div className="flex items-center gap-2 text-indigo-600 mb-1">
                <Globe className="w-4 h-4" />
                <p className="text-indigo-900">Países</p>
              </div>
              <p className="text-gray-900">{profile.targetCountries.length}</p>
            </div>
            <div>
              <div className="flex items-center gap-2 text-indigo-600 mb-1">
                <Building2 className="w-4 h-4" />
                <p className="text-indigo-900">Universidades</p>
              </div>
              <p className="text-gray-900">{profile.targetUniversities.length}</p>
            </div>
            <div>
              <div className="flex items-center gap-2 text-indigo-600 mb-1">
                <FileText className="w-4 h-4" />
                <p className="text-indigo-900">Programa</p>
              </div>
              <p className="text-gray-900">{profile.programType}</p>
            </div>
            <div>
              <div className="flex items-center gap-2 text-indigo-600 mb-1">
                <BookOpen className="w-4 h-4" />
                <p className="text-indigo-900">Área</p>
              </div>
              <p className="text-gray-900">{profile.fieldOfStudy}</p>
            </div>
          </div>
        </div>

        {/* Important Notice */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 flex gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-amber-900 mb-1">⚠️ Informação Importante</p>
            <p className="text-amber-700">
              Cada universidade tem requisitos específicos. Os documentos listados são baseados em 
              requisitos gerais e podem variar. <strong>Sempre confirme diretamente com cada universidade</strong> 
              para obter a lista mais atualizada e específica.
            </p>
          </div>
        </div>

        {/* Universities List */}
        <div className="space-y-4">
          {allUniversityDocs.map((uniDocs, index) => {
            const isExpanded = expandedUniversity === uniDocs.universityName;
            const requiredDocs = uniDocs.documents.filter(d => d.required);
            const optionalDocs = uniDocs.documents.filter(d => !d.required);
            const categories = Array.from(new Set(uniDocs.documents.map(d => d.category)));
            const countryData = countriesData.find(c => c.name === uniDocs.country);

            return (
              <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden">
                {/* University Header */}
                <button
                  onClick={() => toggleUniversity(uniDocs.universityName)}
                  className="w-full p-6 flex items-center justify-between hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                      <span className="text-2xl">{countryData?.flag || '🎓'}</span>
                    </div>
                    <div className="text-left">
                      <h3 className="text-gray-900">{uniDocs.universityName}</h3>
                      <p className="text-gray-600">{uniDocs.country}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-gray-900">{uniDocs.documents.length} documentos</p>
                      <p className="text-gray-600">{requiredDocs.length} obrigatórios</p>
                    </div>
                    {isExpanded ? (
                      <ChevronUp className="w-6 h-6 text-gray-400" />
                    ) : (
                      <ChevronDown className="w-6 h-6 text-gray-400" />
                    )}
                  </div>
                </button>

                {/* Expanded Content */}
                {isExpanded && (
                  <div className="px-6 pb-6 border-t border-gray-200">
                    {/* Specific Notes */}
                    {uniDocs.specificNotes && uniDocs.specificNotes.length > 0 && (
                      <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <p className="text-blue-900 mb-2">📋 Informações Específicas</p>
                        <ul className="space-y-1">
                          {uniDocs.specificNotes.map((note, idx) => (
                            <li key={idx} className="text-blue-700">{note}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Required Documents */}
                    <div className="mt-6">
                      <div className="flex items-center gap-2 mb-4">
                        <CheckCircle2 className="w-5 h-5 text-green-600" />
                        <h4 className="text-gray-900">Documentos Obrigatórios</h4>
                        <span className="ml-auto px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">
                          {requiredDocs.length}
                        </span>
                      </div>

                      <div className="space-y-4">
                        {categories.map(category => {
                          const categoryDocs = requiredDocs.filter(d => d.category === category);
                          if (categoryDocs.length === 0) return null;

                          return (
                            <div key={category}>
                              <p className="text-gray-700 mb-2">{category}</p>
                              <div className="space-y-2">
                                {categoryDocs.map(doc => (
                                  <div key={doc.id} className="p-3 border border-gray-200 rounded-lg hover:border-indigo-300 transition-colors bg-gray-50">
                                    <div className="flex items-start justify-between gap-3 mb-1">
                                      <p className="text-gray-900">{doc.name}</p>
                                      <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded text-xs flex-shrink-0">
                                        Obrigatório
                                      </span>
                                    </div>
                                    <p className="text-gray-600 text-sm mb-2">{doc.description}</p>
                                    {(doc.processingTime || doc.notes) && (
                                      <div className="space-y-1">
                                        {doc.processingTime && (
                                          <p className="text-gray-500 text-sm flex items-center gap-1">
                                            <Calendar className="w-3 h-3" />
                                            {doc.processingTime}
                                          </p>
                                        )}
                                        {doc.notes && (
                                          <p className="text-gray-500 text-sm flex items-start gap-1">
                                            <AlertCircle className="w-3 h-3 flex-shrink-0 mt-0.5" />
                                            {doc.notes}
                                          </p>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                ))}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Optional Documents */}
                    {optionalDocs.length > 0 && (
                      <div className="mt-6">
                        <div className="flex items-center gap-2 mb-4">
                          <FileText className="w-5 h-5 text-blue-600" />
                          <h4 className="text-gray-900">Documentos Opcionais ou Condicionais</h4>
                          <span className="ml-auto px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">
                            {optionalDocs.length}
                          </span>
                        </div>

                        <div className="space-y-2">
                          {optionalDocs.map(doc => (
                            <div key={doc.id} className="p-3 border border-gray-200 rounded-lg hover:border-blue-300 transition-colors">
                              <div className="flex items-start justify-between gap-3 mb-1">
                                <p className="text-gray-900">{doc.name}</p>
                                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs flex-shrink-0">
                                  Opcional
                                </span>
                              </div>
                              <p className="text-gray-600 text-sm mb-2">{doc.description}</p>
                              {(doc.processingTime || doc.notes) && (
                                <div className="space-y-1">
                                  {doc.processingTime && (
                                    <p className="text-gray-500 text-sm flex items-center gap-1">
                                      <Calendar className="w-3 h-3" />
                                      {doc.processingTime}
                                    </p>
                                  )}
                                  {doc.notes && (
                                    <p className="text-gray-500 text-sm flex items-start gap-1">
                                      <AlertCircle className="w-3 h-3 flex-shrink-0 mt-0.5" />
                                      {doc.notes}
                                    </p>
                                  )}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Timeline Tip */}
        <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-6 mt-6">
          <h3 className="text-indigo-900 mb-3">💡 Dica de Timeline</h3>
          <p className="text-indigo-700 mb-4">
            Como você está aplicando para {profile.targetUniversities.length} universidade(s), 
            recomendamos começar com pelo menos <strong>8 meses de antecedência</strong>. 
            Organize os documentos uma vez e use para múltiplas aplicações.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-lg">
              <p className="text-indigo-900 mb-1">8 meses antes</p>
              <p className="text-gray-600">Pesquisar requisitos de cada universidade</p>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <p className="text-indigo-900 mb-1">6 meses antes</p>
              <p className="text-gray-600">Solicitar documentos e traduções</p>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <p className="text-indigo-900 mb-1">3-4 meses antes</p>
              <p className="text-gray-600">Submeter aplicações</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}