import { useState } from 'react';
import { ChevronLeft, ChevronRight, Check, X, Library } from 'lucide-react';
import { UserProfile } from '../App';
import { UniversityBrowser } from './UniversityBrowser';
import { countriesData } from '../utils/countryData';

type QuestionnaireProps = {
  onComplete: (profile: UserProfile) => void;
  onBack: () => void;
};

const educationLevels = [
  'Ensino Médio Completo',
  'Ensino Superior Incompleto',
  'Ensino Superior Completo',
  'Pós-Graduação',
  'Mestrado',
  'Doutorado'
];

const programTypes = [
  'Graduação',
  'Pós-Graduação',
  'Mestrado',
  'Doutorado',
  'MBA',
  'Curso Técnico',
  'Intercâmbio'
];

const fieldsOfStudy = [
  'Engenharia',
  'Medicina',
  'Direito',
  'Administração',
  'Ciências da Computação',
  'Economia',
  'Psicologia',
  'Arquitetura',
  'Design',
  'Artes',
  'Ciências Biológicas',
  'Física',
  'Química',
  'Matemática',
  'Letras',
  'Filosofia',
  'História'
];

export function Questionnaire({ onComplete, onBack }: QuestionnaireProps) {
  const [step, setStep] = useState(1);
  const [showBrowser, setShowBrowser] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    country: '',
    educationLevel: '',
    targetCountries: [] as string[],
    targetUniversities: [] as string[],
    fieldOfStudy: '',
    programType: ''
  });

  const totalSteps = 5;

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      onComplete(formData as UserProfile);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    } else {
      onBack();
    }
  };

  const isStepValid = () => {
    switch (step) {
      case 1:
        return formData.name && formData.email;
      case 2:
        return formData.country && formData.educationLevel;
      case 3:
        return formData.targetCountries.length > 0;
      case 4:
        return formData.targetUniversities.length > 0;
      case 5:
        return formData.fieldOfStudy && formData.programType;
      default:
        return false;
    }
  };

  const toggleCountry = (country: string) => {
    setFormData(prev => ({
      ...prev,
      targetCountries: prev.targetCountries.includes(country)
        ? prev.targetCountries.filter(c => c !== country)
        : [...prev.targetCountries, country]
    }));
  };

  const removeCountry = (country: string) => {
    setFormData(prev => ({
      ...prev,
      targetCountries: prev.targetCountries.filter(c => c !== country),
      // Remove universidades deste país
      targetUniversities: prev.targetUniversities.filter(uni => {
        const countryData = countriesData.find(c => c.name === country);
        return !countryData?.universities.some(u => u.name === uni);
      })
    }));
  };

  const handleUniversitiesSelected = (universities: string[]) => {
    setFormData(prev => ({
      ...prev,
      targetUniversities: universities
    }));
    setShowBrowser(false);
  };

  const removeUniversity = (university: string) => {
    setFormData(prev => ({
      ...prev,
      targetUniversities: prev.targetUniversities.filter(u => u !== university)
    }));
  };

  if (showBrowser) {
    return (
      <UniversityBrowser
        selectedCountries={formData.targetCountries}
        selectedUniversities={formData.targetUniversities}
        onComplete={handleUniversitiesSelected}
        onBack={() => setShowBrowser(false)}
      />
    );
  }

  return (
    <div className="min-h-screen p-6 flex items-center justify-center">
      <div className="w-full max-w-3xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <p className="text-gray-600">Etapa {step} de {totalSteps}</p>
            <p className="text-gray-600">{Math.round((step / totalSteps) * 100)}%</p>
          </div>
          <div className="h-2 bg-white rounded-full overflow-hidden">
            <div 
              className="h-full bg-indigo-600 transition-all duration-300"
              style={{ width: `${(step / totalSteps) * 100}%` }}
            />
          </div>
        </div>

        {/* Form Card */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {/* Step 1: Personal Info */}
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-gray-900 mb-2">Informações Pessoais</h2>
                <p className="text-gray-600">Vamos começar com algumas informações básicas sobre você</p>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Nome Completo</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="Seu nome completo"
                />
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="seu@email.com"
                />
              </div>
            </div>
          )}

          {/* Step 2: Current Education */}
          {step === 2 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-gray-900 mb-2">Sua Educação Atual</h2>
                <p className="text-gray-600">Conte-nos sobre sua formação acadêmica</p>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">País de Origem</label>
                <select
                  value={formData.country}
                  onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">Selecione seu país</option>
                  {countriesData.map(country => (
                    <option key={country.name} value={country.name}>
                      {country.flag} {country.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Nível de Educação Atual</label>
                <select
                  value={formData.educationLevel}
                  onChange={(e) => setFormData({ ...formData, educationLevel: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">Selecione seu nível</option>
                  {educationLevels.map(level => (
                    <option key={level} value={level}>{level}</option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* Step 3: Target Countries */}
          {step === 3 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-gray-900 mb-2">Países de Destino</h2>
                <p className="text-gray-600">Selecione um ou mais países onde deseja estudar</p>
              </div>

              {/* Selected Countries */}
              {formData.targetCountries.length > 0 && (
                <div className="flex flex-wrap gap-2 p-4 bg-indigo-50 rounded-lg">
                  {formData.targetCountries.map(country => {
                    const countryData = countriesData.find(c => c.name === country);
                    return (
                      <div
                        key={country}
                        className="inline-flex items-center gap-2 px-3 py-2 bg-white rounded-lg border border-indigo-200"
                      >
                        <span>{countryData?.flag}</span>
                        <span className="text-gray-900">{country}</span>
                        <button
                          onClick={() => removeCountry(country)}
                          className="text-gray-400 hover:text-red-500"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}

              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 max-h-96 overflow-y-auto">
                {countriesData.map(country => (
                  <button
                    key={country.name}
                    onClick={() => toggleCountry(country.name)}
                    className={`p-4 border-2 rounded-lg transition-all ${
                      formData.targetCountries.includes(country.name)
                        ? 'border-indigo-600 bg-indigo-50'
                        : 'border-gray-200 hover:border-indigo-300'
                    }`}
                  >
                    <div className="flex flex-col items-center gap-2">
                      <span className="text-3xl">{country.flag}</span>
                      <span className="text-gray-900 text-center">{country.name}</span>
                      {formData.targetCountries.includes(country.name) && (
                        <Check className="w-5 h-5 text-indigo-600" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 4: Target Universities */}
          {step === 4 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-gray-900 mb-2">Universidades de Destino</h2>
                <p className="text-gray-600">Selecione as universidades onde deseja se matricular</p>
              </div>

              {formData.targetCountries.length === 0 ? (
                <div className="p-8 bg-amber-50 border border-amber-200 rounded-lg text-center">
                  <p className="text-amber-900">
                    Por favor, volte e selecione pelo menos um país de destino
                  </p>
                </div>
              ) : (
                <>
                  {/* Selected Universities */}
                  {formData.targetUniversities.length > 0 && (
                    <div className="space-y-2 p-4 bg-indigo-50 rounded-lg">
                      <p className="text-indigo-900">
                        {formData.targetUniversities.length} universidade(s) selecionada(s)
                      </p>
                      {formData.targetUniversities.map(university => (
                        <div
                          key={university}
                          className="flex items-center justify-between p-3 bg-white rounded-lg border border-indigo-200"
                        >
                          <span className="text-gray-900">{university}</span>
                          <button
                            onClick={() => removeUniversity(university)}
                            className="text-gray-400 hover:text-red-500"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <button
                    onClick={() => setShowBrowser(true)}
                    className="w-full p-6 border-2 border-dashed border-indigo-300 rounded-lg hover:border-indigo-500 hover:bg-indigo-50 transition-all"
                  >
                    <div className="flex flex-col items-center gap-3">
                      <Library className="w-8 h-8 text-indigo-600" />
                      <div>
                        <p className="text-gray-900">Abrir Biblioteca de Universidades</p>
                        <p className="text-gray-600">
                          Navegue por {countriesData.reduce((acc, c) => acc + c.universities.length, 0)}+ universidades
                        </p>
                      </div>
                    </div>
                  </button>
                </>
              )}
            </div>
          )}

          {/* Step 5: Program Details */}
          {step === 5 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-gray-900 mb-2">Detalhes do Programa</h2>
                <p className="text-gray-600">Qual curso você deseja fazer?</p>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Área de Estudo</label>
                <select
                  value={formData.fieldOfStudy}
                  onChange={(e) => setFormData({ ...formData, fieldOfStudy: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">Selecione a área</option>
                  {fieldsOfStudy.map(field => (
                    <option key={field} value={field}>{field}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Tipo de Programa</label>
                <select
                  value={formData.programType}
                  onChange={(e) => setFormData({ ...formData, programType: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">Selecione o tipo</option>
                  {programTypes.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
            <button
              onClick={handleBack}
              className="px-6 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors inline-flex items-center gap-2"
            >
              <ChevronLeft className="w-5 h-5" />
              {step === 1 ? 'Voltar ao Dashboard' : 'Anterior'}
            </button>

            <button
              onClick={handleNext}
              disabled={!isStepValid()}
              className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors inline-flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {step === totalSteps ? 'Gerar Resultados' : 'Próximo'}
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
