import { GraduationCap, FileText, Globe, TrendingUp, Search, BookOpen } from 'lucide-react';

type DashboardProps = {
  onStartQuestionnaire: () => void;
};

export function Dashboard({ onStartQuestionnaire }: DashboardProps) {
  const recentSearches = [
    { university: 'Universidade de São Paulo (USP)', country: 'Brasil', date: '2 dias atrás' },
    { university: 'Harvard University', country: 'Estados Unidos', date: '1 semana atrás' },
  ];

  const popularUniversities = [
    { name: 'MIT', country: 'Estados Unidos', applications: '12.5k' },
    { name: 'Oxford', country: 'Reino Unido', applications: '10.2k' },
    { name: 'USP', country: 'Brasil', applications: '8.7k' },
    { name: 'Universidade de Coimbra', country: 'Portugal', applications: '6.3k' },
  ];

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-indigo-900">UniDocs AI</h1>
              <p className="text-gray-600">Bem-vindo de volta!</p>
            </div>
          </div>
          <button className="px-4 py-2 bg-white rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">
            Meu Perfil
          </button>
        </div>

        {/* Main CTA */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-8 mb-8 text-white">
          <div className="max-w-2xl">
            <h2 className="mb-4">Descubra os Documentos Necessários</h2>
            <p className="mb-6 opacity-90">
              Responda algumas perguntas e nossa IA identificará todos os documentos 
              necessários para sua matrícula na universidade desejada.
            </p>
            <button
              onClick={onStartQuestionnaire}
              className="px-6 py-3 bg-white text-indigo-600 rounded-lg hover:bg-gray-100 transition-colors inline-flex items-center gap-2"
            >
              <Search className="w-5 h-5" />
              Iniciar Nova Busca
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Globe className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-gray-600">Universidades</p>
                <p className="text-gray-900">2.500+</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-gray-600">Documentos Catalogados</p>
                <p className="text-gray-900">15.000+</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-gray-600">Taxa de Sucesso</p>
                <p className="text-gray-900">94%</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Searches */}
          <div className="bg-white rounded-xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <BookOpen className="w-5 h-5 text-indigo-600" />
              <h3 className="text-gray-900">Buscas Recentes</h3>
            </div>
            {recentSearches.length > 0 ? (
              <div className="space-y-3">
                {recentSearches.map((search, idx) => (
                  <div key={idx} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
                    <p className="text-gray-900">{search.university}</p>
                    <div className="flex items-center justify-between mt-1">
                      <p className="text-gray-500">{search.country}</p>
                      <p className="text-gray-400">{search.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8">
                Você ainda não fez nenhuma busca
              </p>
            )}
          </div>

          {/* Popular Universities */}
          <div className="bg-white rounded-xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-indigo-600" />
              <h3 className="text-gray-900">Universidades Populares</h3>
            </div>
            <div className="space-y-3">
              {popularUniversities.map((uni, idx) => (
                <div key={idx} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-900">{uni.name}</p>
                      <p className="text-gray-500">{uni.country}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-indigo-600">{uni.applications}</p>
                      <p className="text-gray-400">buscas</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
