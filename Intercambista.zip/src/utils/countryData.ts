export type Country = {
  name: string;
  flag: string;
  universities: University[];
};

export type University = {
  name: string;
  city: string;
  ranking?: number;
  type: string; // Public, Private, etc.
  specificRequirements?: string[]; // Requirements specific to this university
  applicationDeadline?: string;
  website?: string;
};

export const countriesData: Country[] = [
  // --- AMÉRICA DO SUL ---
  {
    name: 'Brasil',
    flag: '🇧🇷',
    universities: [
      { name: 'Universidade de São Paulo (USP)', city: 'São Paulo', ranking: 1, type: 'Pública' },
      { name: 'Universidade Estadual de Campinas (UNICAMP)', city: 'Campinas', ranking: 2, type: 'Pública' },
      { name: 'Universidade Federal do Rio de Janeiro (UFRJ)', city: 'Rio de Janeiro', ranking: 3, type: 'Pública' },
      { name: 'Universidade de Brasília (UnB)', city: 'Brasília', ranking: 4, type: 'Pública' },
      { name: 'Universidade Federal de Minas Gerais (UFMG)', city: 'Belo Horizonte', ranking: 5, type: 'Pública' },
      { name: 'Universidade Federal do Rio Grande do Sul (UFRGS)', city: 'Porto Alegre', type: 'Pública' },
      { name: 'Pontifícia Universidade Católica do Rio de Janeiro (PUC-Rio)', city: 'Rio de Janeiro', type: 'Privada' },
      { name: 'Universidade Federal de São Paulo (UNIFESP)', city: 'São Paulo', type: 'Pública' },
      { name: 'Instituto Tecnológico de Aeronáutica (ITA)', city: 'São José dos Campos', type: 'Pública' },
      { name: 'Universidade Estadual Paulista (UNESP)', city: 'São Paulo', type: 'Pública' },
      { name: 'Universidade Federal de Santa Catarina (UFSC)', city: 'Florianópolis', type: 'Pública' },
      { name: 'Universidade Federal de Pernambuco (UFPE)', city: 'Recife', type: 'Pública' },
      { name: 'Universidade Federal do Ceará (UFC)', city: 'Fortaleza', type: 'Pública' },
      { name: 'Universidade Federal do Paraná (UFPR)', city: 'Curitiba', type: 'Pública' },
      { name: 'Universidade Federal da Bahia (UFBA)', city: 'Salvador', type: 'Pública' },
      { name: 'Universidade Federal de São Carlos (UFSCar)', city: 'São Carlos', type: 'Pública' },
      { name: 'Fundação Getulio Vargas (FGV)', city: 'São Paulo/Rio', type: 'Privada' },
      { name: 'Universidade Presbiteriana Mackenzie', city: 'São Paulo', type: 'Privada' }
    ]
  },
  {
    name: 'Argentina',
    flag: '🇦🇷',
    universities: [
      { name: 'Universidad de Buenos Aires (UBA)', city: 'Buenos Aires', ranking: 1, type: 'Pública' },
      { name: 'Pontificia Universidad Católica Argentina (UCA)', city: 'Buenos Aires', ranking: 2, type: 'Privada' },
      { name: 'Universidad Austral', city: 'Buenos Aires', ranking: 3, type: 'Privada' },
      { name: 'Universidad Nacional de La Plata', city: 'La Plata', type: 'Pública' },
      { name: 'Universidad Nacional de Córdoba', city: 'Córdoba', type: 'Pública' },
      { name: 'Universidad Torcuato Di Tella', city: 'Buenos Aires', type: 'Privada' },
      { name: 'Universidad de San Andrés', city: 'Victoria', type: 'Privada' },
      { name: 'Universidad Tecnológica Nacional (UTN)', city: 'Várias', type: 'Pública' },
      { name: 'ITBA - Instituto Tecnológico de Buenos Aires', city: 'Buenos Aires', type: 'Privada' }
    ]
  },
  {
    name: 'Chile',
    flag: '🇨🇱',
    universities: [
      { name: 'Pontificia Universidad Católica de Chile', city: 'Santiago', ranking: 1, type: 'Privada (Tradicional)' },
      { name: 'Universidad de Chile', city: 'Santiago', ranking: 2, type: 'Pública' },
      { name: 'Universidad de Concepción', city: 'Concepción', ranking: 3, type: 'Privada (Tradicional)' },
      { name: 'Universidad de Santiago de Chile (USACH)', city: 'Santiago', type: 'Pública' },
      { name: 'Pontificia Universidad Católica de Valparaíso', city: 'Valparaíso', type: 'Privada (Tradicional)' },
      { name: 'Universidad Adolfo Ibáñez', city: 'Santiago', type: 'Privada' },
      { name: 'Universidad Técnica Federico Santa María', city: 'Valparaíso', type: 'Privada (Tradicional)' }
    ]
  },
  {
    name: 'Colômbia',
    flag: '🇨🇴',
    universities: [
      { name: 'Universidad de los Andes', city: 'Bogotá', ranking: 1, type: 'Privada' },
      { name: 'Universidad Nacional de Colombia', city: 'Bogotá', ranking: 2, type: 'Pública' },
      { name: 'Pontificia Universidad Javeriana', city: 'Bogotá', ranking: 3, type: 'Privada' },
      { name: 'Universidad de Antioquia', city: 'Medellín', type: 'Pública' },
      { name: 'Universidad del Rosario', city: 'Bogotá', type: 'Privada' },
      { name: 'Universidad del Valle', city: 'Cali', type: 'Pública' },
      { name: 'Universidad EAFIT', city: 'Medellín', type: 'Privada' }
    ]
  },

  // --- AMÉRICA DO NORTE ---
  {
    name: 'Estados Unidos',
    flag: '🇺🇸',
    universities: [
      { name: 'Harvard University', city: 'Cambridge', ranking: 1, type: 'Privada' },
      { name: 'MIT (Massachusetts Institute of Technology)', city: 'Cambridge', ranking: 2, type: 'Privada' },
      { name: 'Stanford University', city: 'Stanford', ranking: 3, type: 'Privada' },
      { name: 'Yale University', city: 'New Haven', ranking: 4, type: 'Privada' },
      { name: 'Princeton University', city: 'Princeton', ranking: 5, type: 'Privada' },
      { name: 'Columbia University', city: 'New York', type: 'Privada' },
      { name: 'Caltech (California Institute of Technology)', city: 'Pasadena', type: 'Privada' },
      { name: 'University of Chicago', city: 'Chicago', type: 'Privada' },
      { name: 'Cornell University', city: 'Ithaca', type: 'Privada' },
      { name: 'University of Pennsylvania (UPenn)', city: 'Philadelphia', type: 'Privada' },
      { name: 'Johns Hopkins University', city: 'Baltimore', type: 'Privada' },
      { name: 'University of California, Berkeley (UC Berkeley)', city: 'Berkeley', type: 'Pública' },
      { name: 'UCLA', city: 'Los Angeles', type: 'Pública' },
      { name: 'New York University (NYU)', city: 'New York', type: 'Privada' },
      { name: 'Duke University', city: 'Durham', type: 'Privada' },
      { name: 'University of Michigan', city: 'Ann Arbor', type: 'Pública' },
      { name: 'Northwestern University', city: 'Evanston', type: 'Privada' },
      { name: 'Carnegie Mellon University', city: 'Pittsburgh', type: 'Privada' },
      { name: 'University of Washington', city: 'Seattle', type: 'Pública' },
      { name: 'Georgia Tech', city: 'Atlanta', type: 'Pública' },
      { name: 'University of Texas at Austin', city: 'Austin', type: 'Pública' }
    ]
  },
  {
    name: 'Canadá',
    flag: '🇨🇦',
    universities: [
      { name: 'University of Toronto', city: 'Toronto', ranking: 1, type: 'Pública' },
      { name: 'McGill University', city: 'Montreal', ranking: 2, type: 'Pública' },
      { name: 'University of British Columbia (UBC)', city: 'Vancouver', ranking: 3, type: 'Pública' },
      { name: 'University of Alberta', city: 'Edmonton', type: 'Pública' },
      { name: 'McMaster University', city: 'Hamilton', type: 'Pública' },
      { name: 'University of Waterloo', city: 'Waterloo', type: 'Pública' },
      { name: 'Université de Montréal', city: 'Montreal', type: 'Pública' },
      { name: 'University of Calgary', city: 'Calgary', type: 'Pública' },
      { name: 'Western University', city: 'London', type: 'Pública' },
      { name: 'Queen\'s University', city: 'Kingston', type: 'Pública' },
      { name: 'Simon Fraser University', city: 'Burnaby', type: 'Pública' },
      { name: 'Dalhousie University', city: 'Halifax', type: 'Pública' },
      { name: 'University of Ottawa', city: 'Ottawa', type: 'Pública' }
    ]
  },
  {
    name: 'México',
    flag: '🇲🇽',
    universities: [
      { name: 'UNAM - Universidad Nacional Autónoma de México', city: 'Cidade do México', ranking: 1, type: 'Pública' },
      { name: 'Tecnológico de Monterrey', city: 'Monterrey', ranking: 2, type: 'Privada' },
      { name: 'IPN - Instituto Politécnico Nacional', city: 'Cidade do México', type: 'Pública' },
      { name: 'UAM - Universidad Autónoma Metropolitana', city: 'Cidade do México', type: 'Pública' },
      { name: 'Universidad Iberoamericana', city: 'Cidade do México', type: 'Privada' },
      { name: 'ITAM - Instituto Tecnológico Autónomo de México', city: 'Cidade do México', type: 'Privada' },
      { name: 'Universidad de Guadalajara', city: 'Guadalajara', type: 'Pública' }
    ]
  },

  // --- EUROPA ---
  {
    name: 'Reino Unido',
    flag: '🇬🇧',
    universities: [
      { name: 'University of Oxford', city: 'Oxford', ranking: 1, type: 'Pública' },
      { name: 'University of Cambridge', city: 'Cambridge', ranking: 2, type: 'Pública' },
      { name: 'Imperial College London', city: 'London', ranking: 3, type: 'Pública' },
      { name: 'UCL (University College London)', city: 'London', ranking: 4, type: 'Pública' },
      { name: 'LSE (London School of Economics)', city: 'London', ranking: 5, type: 'Pública' },
      { name: 'University of Edinburgh', city: 'Edinburgh', type: 'Pública' },
      { name: 'King\'s College London', city: 'London', type: 'Pública' },
      { name: 'University of Manchester', city: 'Manchester', type: 'Pública' },
      { name: 'University of Bristol', city: 'Bristol', type: 'Pública' },
      { name: 'University of Warwick', city: 'Coventry', type: 'Pública' },
      { name: 'University of Glasgow', city: 'Glasgow', type: 'Pública' },
      { name: 'University of Birmingham', city: 'Birmingham', type: 'Pública' },
      { name: 'University of Sheffield', city: 'Sheffield', type: 'Pública' },
      { name: 'University of Leeds', city: 'Leeds', type: 'Pública' },
      { name: 'University of Southampton', city: 'Southampton', type: 'Pública' },
      { name: 'Durham University', city: 'Durham', type: 'Pública' }
    ]
  },
  {
    name: 'Alemanha',
    flag: '🇩🇪',
    universities: [
      { name: 'TUM - Technical University of Munich', city: 'Munich', ranking: 1, type: 'Pública' },
      { name: 'LMU Munich', city: 'Munich', ranking: 2, type: 'Pública' },
      { name: 'Heidelberg University', city: 'Heidelberg', ranking: 3, type: 'Pública' },
      { name: 'Humboldt University of Berlin', city: 'Berlin', type: 'Pública' },
      { name: 'Free University of Berlin', city: 'Berlin', type: 'Pública' },
      { name: 'RWTH Aachen University', city: 'Aachen', type: 'Pública' },
      { name: 'KIT - Karlsruhe Institute of Technology', city: 'Karlsruhe', type: 'Pública' },
      { name: 'Technical University of Berlin', city: 'Berlin', type: 'Pública' },
      { name: 'University of Freiburg', city: 'Freiburg', type: 'Pública' },
      { name: 'University of Tübingen', city: 'Tübingen', type: 'Pública' },
      { name: 'TU Dresden', city: 'Dresden', type: 'Pública' },
      { name: 'University of Bonn', city: 'Bonn', type: 'Pública' }
    ]
  },
  {
    name: 'França',
    flag: '🇫🇷',
    universities: [
      { name: 'Université PSL', city: 'Paris', ranking: 1, type: 'Pública' },
      { name: 'Institut Polytechnique de Paris', city: 'Palaiseau', ranking: 2, type: 'Pública' },
      { name: 'Sorbonne University', city: 'Paris', ranking: 3, type: 'Pública' },
      { name: 'Université Paris-Saclay', city: 'Paris', type: 'Pública' },
      { name: 'Sciences Po', city: 'Paris', type: 'Privada/Pública' },
      { name: 'École Normale Supérieure de Lyon', city: 'Lyon', type: 'Pública' },
      { name: 'Université Paris Cité', city: 'Paris', type: 'Pública' },
      { name: 'Université Grenoble Alpes', city: 'Grenoble', type: 'Pública' },
      { name: 'University of Strasbourg', city: 'Strasbourg', type: 'Pública' },
      { name: 'Aix-Marseille University', city: 'Marseille', type: 'Pública' }
    ]
  },
  {
    name: 'Espanha',
    flag: '🇪🇸',
    universities: [
      { name: 'Universitat de Barcelona', city: 'Barcelona', ranking: 1, type: 'Pública' },
      { name: 'Universitat Autònoma de Barcelona', city: 'Barcelona', ranking: 2, type: 'Pública' },
      { name: 'Universidad Autónoma de Madrid', city: 'Madrid', ranking: 3, type: 'Pública' },
      { name: 'Universidad Complutense de Madrid', city: 'Madrid', type: 'Pública' },
      { name: 'Universitat Pompeu Fabra', city: 'Barcelona', type: 'Pública' },
      { name: 'Universidad de Navarra', city: 'Pamplona', type: 'Privada' },
      { name: 'Universitat de València', city: 'Valencia', type: 'Pública' },
      { name: 'Universidad Politécnica de Madrid', city: 'Madrid', type: 'Pública' },
      { name: 'Universitat Politècnica de Catalunya', city: 'Barcelona', type: 'Pública' },
      { name: 'Universidad Carlos III de Madrid', city: 'Madrid', type: 'Pública' }
    ]
  },
  {
    name: 'Portugal',
    flag: '🇵🇹',
    universities: [
      { name: 'Universidade de Lisboa', city: 'Lisboa', ranking: 1, type: 'Pública' },
      { name: 'Universidade do Porto', city: 'Porto', ranking: 2, type: 'Pública' },
      { name: 'Universidade de Coimbra', city: 'Coimbra', ranking: 3, type: 'Pública' },
      { name: 'Universidade Nova de Lisboa', city: 'Lisboa', type: 'Pública' },
      { name: 'Universidade do Minho', city: 'Braga', type: 'Pública' },
      { name: 'Universidade de Aveiro', city: 'Aveiro', type: 'Pública' },
      { name: 'Universidade Católica Portuguesa', city: 'Lisboa/Porto', type: 'Privada' },
      { name: 'Universidade de Trás-os-Montes e Alto Douro', city: 'Vila Real', type: 'Pública' },
      { name: 'Universidade do Algarve', city: 'Faro', type: 'Pública' },
      { name: 'ISCTE - Instituto Universitário de Lisboa', city: 'Lisboa', type: 'Pública' },
      { name: 'Universidade da Beira Interior', city: 'Covilhã', type: 'Pública' }
    ]
  },
  {
    name: 'Itália',
    flag: '🇮🇹',
    universities: [
      { name: 'Politecnico di Milano', city: 'Milan', ranking: 1, type: 'Pública' },
      { name: 'Sapienza University of Rome', city: 'Rome', ranking: 2, type: 'Pública' },
      { name: 'University of Bologna', city: 'Bologna', ranking: 3, type: 'Pública' },
      { name: 'University of Padua', city: 'Padua', type: 'Pública' },
      { name: 'University of Milan', city: 'Milan', type: 'Pública' },
      { name: 'Politecnico di Torino', city: 'Turin', type: 'Pública' },
      { name: 'University of Pisa', city: 'Pisa', type: 'Pública' },
      { name: 'University of Naples Federico II', city: 'Naples', type: 'Pública' },
      { name: 'Vita-Salute San Raffaele University', city: 'Milan', type: 'Privada' },
      { name: 'University of Florence', city: 'Florence', type: 'Pública' },
      { name: 'University of Trento', city: 'Trento', type: 'Pública' }
    ]
  },
  {
    name: 'Holanda',
    flag: '🇳🇱',
    universities: [
      { name: 'Delft University of Technology', city: 'Delft', ranking: 1, type: 'Pública' },
      { name: 'University of Amsterdam', city: 'Amsterdam', ranking: 2, type: 'Pública' },
      { name: 'Utrecht University', city: 'Utrecht', ranking: 3, type: 'Pública' },
      { name: 'Wageningen University & Research', city: 'Wageningen', type: 'Pública' },
      { name: 'Leiden University', city: 'Leiden', type: 'Pública' },
      { name: 'Erasmus University Rotterdam', city: 'Rotterdam', type: 'Pública' },
      { name: 'University of Groningen', city: 'Groningen', type: 'Pública' },
      { name: 'Maastricht University', city: 'Maastricht', type: 'Pública' },
      { name: 'Vrije Universiteit Amsterdam', city: 'Amsterdam', type: 'Privada/Pública' },
      { name: 'Eindhoven University of Technology', city: 'Eindhoven', type: 'Pública' }
    ]
  },
  {
    name: 'Suíça',
    flag: '🇨🇭',
    universities: [
      { name: 'ETH Zurich', city: 'Zurich', ranking: 1, type: 'Pública' },
      { name: 'EPFL', city: 'Lausanne', ranking: 2, type: 'Pública' },
      { name: 'University of Zurich', city: 'Zurich', ranking: 3, type: 'Pública' },
      { name: 'University of Geneva', city: 'Geneva', type: 'Pública' },
      { name: 'University of Bern', city: 'Bern', type: 'Pública' },
      { name: 'University of Basel', city: 'Basel', type: 'Pública' },
      { name: 'University of Lausanne', city: 'Lausanne', type: 'Pública' },
      { name: 'University of St. Gallen', city: 'St. Gallen', type: 'Pública' }
    ]
  },
  {
    name: 'Suécia',
    flag: '🇸🇪',
    universities: [
      { name: 'KTH Royal Institute of Technology', city: 'Stockholm', ranking: 1, type: 'Pública' },
      { name: 'Lund University', city: 'Lund', ranking: 2, type: 'Pública' },
      { name: 'Uppsala University', city: 'Uppsala', ranking: 3, type: 'Pública' },
      { name: 'Stockholm University', city: 'Stockholm', type: 'Pública' },
      { name: 'Chalmers University of Technology', city: 'Gothenburg', type: 'Privada' },
      { name: 'University of Gothenburg', city: 'Gothenburg', type: 'Pública' },
      { name: 'Karolinska Institute', city: 'Solna', type: 'Pública' },
      { name: 'Linköping University', city: 'Linköping', type: 'Pública' }
    ]
  },
  {
    name: 'Irlanda',
    flag: '🇮🇪',
    universities: [
      { name: 'Trinity College Dublin', city: 'Dublin', ranking: 1, type: 'Pública' },
      { name: 'University College Dublin (UCD)', city: 'Dublin', ranking: 2, type: 'Pública' },
      { name: 'University of Galway', city: 'Galway', type: 'Pública' },
      { name: 'University College Cork', city: 'Cork', type: 'Pública' },
      { name: 'Dublin City University', city: 'Dublin', type: 'Pública' },
      { name: 'University of Limerick', city: 'Limerick', type: 'Pública' },
      { name: 'Maynooth University', city: 'Maynooth', type: 'Pública' }
    ]
  },
  {
    name: 'Bélgica',
    flag: '🇧🇪',
    universities: [
      { name: 'KU Leuven', city: 'Leuven', ranking: 1, type: 'Pública' },
      { name: 'Ghent University', city: 'Ghent', ranking: 2, type: 'Pública' },
      { name: 'UCLouvain', city: 'Ottignies-Louvain-la-Neuve', type: 'Pública' },
      { name: 'Université Libre de Bruxelles', city: 'Brussels', type: 'Pública' },
      { name: 'Vrije Universiteit Brussel', city: 'Brussels', type: 'Pública' },
      { name: 'University of Antwerp', city: 'Antwerp', type: 'Pública' },
      { name: 'University of Liège', city: 'Liège', type: 'Pública' }
    ]
  },
  {
    name: 'Dinamarca',
    flag: '🇩🇰',
    universities: [
      { name: 'University of Copenhagen', city: 'Copenhagen', ranking: 1, type: 'Pública' },
      { name: 'Technical University of Denmark (DTU)', city: 'Lyngby', ranking: 2, type: 'Pública' },
      { name: 'Aarhus University', city: 'Aarhus', type: 'Pública' },
      { name: 'Aalborg University', city: 'Aalborg', type: 'Pública' },
      { name: 'University of Southern Denmark', city: 'Odense', type: 'Pública' },
      { name: 'Copenhagen Business School', city: 'Copenhagen', type: 'Pública' }
    ]
  },
  {
    name: 'Noruega',
    flag: '🇳🇴',
    universities: [
      { name: 'University of Oslo', city: 'Oslo', ranking: 1, type: 'Pública' },
      { name: 'University of Bergen', city: 'Bergen', type: 'Pública' },
      { name: 'NTNU - Norwegian University of Science and Technology', city: 'Trondheim', type: 'Pública' },
      { name: 'UiT The Arctic University of Norway', city: 'Tromsø', type: 'Pública' },
      { name: 'Norwegian University of Life Sciences', city: 'Ås', type: 'Pública' }
    ]
  },
  {
    name: 'Finlândia',
    flag: '🇫🇮',
    universities: [
      { name: 'University of Helsinki', city: 'Helsinki', ranking: 1, type: 'Pública' },
      { name: 'Aalto University', city: 'Espoo', ranking: 2, type: 'Pública' },
      { name: 'University of Turku', city: 'Turku', type: 'Pública' },
      { name: 'University of Jyväskylä', city: 'Jyväskylä', type: 'Pública' },
      { name: 'University of Oulu', city: 'Oulu', type: 'Pública' },
      { name: 'Tampere University', city: 'Tampere', type: 'Pública' }
    ]
  },
  {
    name: 'Áustria',
    flag: '🇦🇹',
    universities: [
      { name: 'University of Vienna', city: 'Vienna', ranking: 1, type: 'Pública' },
      { name: 'Vienna University of Technology (TU Wien)', city: 'Vienna', ranking: 2, type: 'Pública' },
      { name: 'University of Innsbruck', city: 'Innsbruck', type: 'Pública' },
      { name: 'Graz University of Technology', city: 'Graz', type: 'Pública' },
      { name: 'University of Graz', city: 'Graz', type: 'Pública' },
      { name: 'Medical University of Vienna', city: 'Vienna', type: 'Pública' }
    ]
  },
  {
    name: 'Rússia',
    flag: '🇷🇺',
    universities: [
      { name: 'Lomonosov Moscow State University', city: 'Moscou', ranking: 1, type: 'Pública' },
      { name: 'Saint Petersburg State University', city: 'São Petersburgo', ranking: 2, type: 'Pública' },
      { name: 'Novosibirsk State University', city: 'Novosibirsk', type: 'Pública' },
      { name: 'Tomsk State University', city: 'Tomsk', type: 'Pública' },
      { name: 'Bauman Moscow State Technical University', city: 'Moscou', type: 'Pública' },
      { name: 'Moscow Institute of Physics and Technology (MIPT)', city: 'Dolgoprudny', type: 'Pública' },
      { name: 'HSE University', city: 'Moscou', type: 'Pública' }
    ]
  },

  // --- ÁSIA E OCEANIA ---
  {
    name: 'Japão',
    flag: '🇯🇵',
    universities: [
      { name: 'The University of Tokyo', city: 'Tokyo', ranking: 1, type: 'Pública' },
      { name: 'Kyoto University', city: 'Kyoto', ranking: 2, type: 'Pública' },
      { name: 'Tokyo Institute of Technology', city: 'Tokyo', ranking: 3, type: 'Pública' },
      { name: 'Osaka University', city: 'Osaka', type: 'Pública' },
      { name: 'Tohoku University', city: 'Sendai', type: 'Pública' },
      { name: 'Nagoya University', city: 'Nagoya', type: 'Pública' },
      { name: 'Kyushu University', city: 'Fukuoka', type: 'Pública' },
      { name: 'Hokkaido University', city: 'Sapporo', type: 'Pública' },
      { name: 'Keio University', city: 'Tokyo', type: 'Privada' },
      { name: 'Waseda University', city: 'Tokyo', type: 'Privada' },
      { name: 'University of Tsukuba', city: 'Tsukuba', type: 'Pública' },
      { name: 'Hiroshima University', city: 'Hiroshima', type: 'Pública' },
      { name: 'Kobe University', city: 'Kobe', type: 'Pública' }
    ]
  },
  {
    name: 'China',
    flag: '🇨🇳',
    universities: [
      { name: 'Tsinghua University', city: 'Beijing', ranking: 1, type: 'Pública' },
      { name: 'Peking University', city: 'Beijing', ranking: 2, type: 'Pública' },
      { name: 'Fudan University', city: 'Shanghai', ranking: 3, type: 'Pública' },
      { name: 'Zhejiang University', city: 'Hangzhou', type: 'Pública' },
      { name: 'Shanghai Jiao Tong University', city: 'Shanghai', type: 'Pública' },
      { name: 'University of Science and Technology of China', city: 'Hefei', type: 'Pública' },
      { name: 'Nanjing University', city: 'Nanjing', type: 'Pública' },
      { name: 'Wuhan University', city: 'Wuhan', type: 'Pública' },
      { name: 'Sun Yat-sen University', city: 'Guangzhou', type: 'Pública' },
      { name: 'Harbin Institute of Technology', city: 'Harbin', type: 'Pública' },
      { name: 'Xi\'an Jiaotong University', city: 'Xi\'an', type: 'Pública' },
      { name: 'Tongji University', city: 'Shanghai', type: 'Pública' }
    ]
  },
  {
    name: 'Coreia do Sul',
    flag: '🇰🇷',
    universities: [
      { name: 'Seoul National University', city: 'Seoul', ranking: 1, type: 'Pública' },
      { name: 'KAIST', city: 'Daejeon', ranking: 2, type: 'Pública' },
      { name: 'Yonsei University', city: 'Seoul', ranking: 3, type: 'Privada' },
      { name: 'Korea University', city: 'Seoul', type: 'Privada' },
      { name: 'POSTECH', city: 'Pohang', type: 'Privada' },
      { name: 'Sungkyunkwan University (SKKU)', city: 'Seoul', type: 'Privada' },
      { name: 'Hanyang University', city: 'Seoul', type: 'Privada' },
      { name: 'Kyung Hee University', city: 'Seoul', type: 'Privada' }
    ]
  },
  {
    name: 'Singapura',
    flag: '🇸🇬',
    universities: [
      { name: 'National University of Singapore (NUS)', city: 'Singapore', ranking: 1, type: 'Pública' },
      { name: 'Nanyang Technological University (NTU)', city: 'Singapore', ranking: 2, type: 'Pública' },
      { name: 'Singapore Management University (SMU)', city: 'Singapore', type: 'Pública' },
      { name: 'Singapore University of Technology and Design', city: 'Singapore', type: 'Pública' }
    ]
  },
  {
    name: 'Índia',
    flag: '🇮🇳',
    universities: [
      { name: 'Indian Institute of Technology Bombay (IITB)', city: 'Mumbai', ranking: 1, type: 'Pública' },
      { name: 'Indian Institute of Technology Delhi (IITD)', city: 'New Delhi', ranking: 2, type: 'Pública' },
      { name: 'Indian Institute of Science (IISc)', city: 'Bangalore', ranking: 3, type: 'Pública' },
      { name: 'Indian Institute of Technology Madras (IITM)', city: 'Chennai', type: 'Pública' },
      { name: 'Indian Institute of Technology Kharagpur', city: 'Kharagpur', type: 'Pública' },
      { name: 'University of Delhi', city: 'New Delhi', type: 'Pública' },
      { name: 'Banaras Hindu University', city: 'Varanasi', type: 'Pública' },
      { name: 'Jawaharlal Nehru University', city: 'New Delhi', type: 'Pública' }
    ]
  },
  {
    name: 'Austrália',
    flag: '🇦🇺',
    universities: [
      { name: 'The University of Melbourne', city: 'Melbourne', ranking: 1, type: 'Pública' },
      { name: 'The University of New South Wales (UNSW)', city: 'Sydney', ranking: 2, type: 'Pública' },
      { name: 'The University of Sydney', city: 'Sydney', ranking: 3, type: 'Pública' },
      { name: 'The Australian National University (ANU)', city: 'Canberra', type: 'Pública' },
      { name: 'Monash University', city: 'Melbourne', type: 'Pública' },
      { name: 'The University of Queensland', city: 'Brisbane', type: 'Pública' },
      { name: 'The University of Western Australia', city: 'Perth', type: 'Pública' },
      { name: 'The University of Adelaide', city: 'Adelaide', type: 'Pública' },
      { name: 'University of Technology Sydney (UTS)', city: 'Sydney', type: 'Pública' },
      { name: 'RMIT University', city: 'Melbourne', type: 'Pública' },
      { name: 'Macquarie University', city: 'Sydney', type: 'Pública' }
    ]
  },
  {
    name: 'Nova Zelândia',
    flag: '🇳🇿',
    universities: [
      { name: 'The University of Auckland', city: 'Auckland', ranking: 1, type: 'Pública' },
      { name: 'University of Otago', city: 'Dunedin', ranking: 2, type: 'Pública' },
      { name: 'Victoria University of Wellington', city: 'Wellington', type: 'Pública' },
      { name: 'University of Canterbury', city: 'Christchurch', type: 'Pública' },
      { name: 'Massey University', city: 'Palmerston North', type: 'Pública' },
      { name: 'University of Waikato', city: 'Hamilton', type: 'Pública' },
      { name: 'Lincoln University', city: 'Lincoln', type: 'Pública' },
      { name: 'Auckland University of Technology (AUT)', city: 'Auckland', type: 'Pública' }
    ]
  },
  {
    name: 'África do Sul',
    flag: '🇿🇦',
    universities: [
      { name: 'University of Cape Town', city: 'Cape Town', ranking: 1, type: 'Pública' },
      { name: 'University of the Witwatersrand', city: 'Johannesburg', ranking: 2, type: 'Pública' },
      { name: 'Stellenbosch University', city: 'Stellenbosch', ranking: 3, type: 'Pública' },
      { name: 'University of Johannesburg', city: 'Johannesburg', type: 'Pública' },
      { name: 'University of Pretoria', city: 'Pretoria', type: 'Pública' },
      { name: 'University of KwaZulu-Natal', city: 'Durban', type: 'Pública' },
      { name: 'Rhodes University', city: 'Grahamstown', type: 'Pública' }
    ]
  },
];

export function getCountryByName(name: string): Country | undefined {
  return countriesData.find(c => c.name === name);
}

export function getUniversitiesByCountry(countryName: string): University[] {
  const country = getCountryByName(countryName);
  return country?.universities || [];
}