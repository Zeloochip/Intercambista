import { useState } from 'react';
import { LoginPage } from './components/LoginPage';
import { Dashboard } from './components/Dashboard';
import { Questionnaire } from './components/Questionnaire';
import { DocumentResults } from './components/DocumentResults';

export type UserProfile = {
  name: string;
  email: string;
  country: string;
  educationLevel: string;
  targetCountries: string[];
  targetUniversities: string[];
  fieldOfStudy: string;
  programType: string;
};

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentView, setCurrentView] = useState<'dashboard' | 'questionnaire' | 'results'>('dashboard');
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  const handleLogin = (email: string, password: string) => {
    // Mock login - in real app, this would validate against backend
    setIsLoggedIn(true);
    setCurrentView('dashboard');
  };

  const handleRegister = (name: string, email: string, password: string) => {
    // Mock registration
    setIsLoggedIn(true);
    setCurrentView('dashboard');
  };

  const handleQuestionnaireComplete = (profile: UserProfile) => {
    setUserProfile(profile);
    setCurrentView('results');
  };

  const handleBackToDashboard = () => {
    setCurrentView('dashboard');
  };

  const handleStartQuestionnaire = () => {
    setCurrentView('questionnaire');
  };

  if (!isLoggedIn) {
    return <LoginPage onLogin={handleLogin} onRegister={handleRegister} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {currentView === 'dashboard' && (
        <Dashboard onStartQuestionnaire={handleStartQuestionnaire} />
      )}
      {currentView === 'questionnaire' && (
        <Questionnaire 
          onComplete={handleQuestionnaireComplete}
          onBack={handleBackToDashboard}
        />
      )}
      {currentView === 'results' && userProfile && (
        <DocumentResults 
          profile={userProfile}
          onBack={handleBackToDashboard}
        />
      )}
    </div>
  );
}